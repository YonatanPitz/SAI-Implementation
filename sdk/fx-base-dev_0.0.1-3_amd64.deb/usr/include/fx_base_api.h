/*
 * fx_base_api.h
 *
 * Machine level APIs for flexible, programmable control of Mellanox switches.
 * These APIs are extensions of the SX APIs from the SDK, and are intended to
 * be a relatively stable interface to an auto-generated implementation.
 * Additional auto generated human friendly SDK and SAI APIs are build on top
 * of these basic APIs.
 *
 * Currently device support: Spectrum
 *
 */

#ifndef _FX_BASE_API_H_
#define _FX_BASE_API_H_
 
#include <stdlib.h>
#include <sx/sdk/sx_status.h>
#include <sx/sdk/sx_api_port.h>
#include <sx/sdk/sx_api_router.h>
#include <flextrum_types.h>
 
#ifdef __cplusplus
extern "C"{
#endif
 
/* an opaque structure. This is the "globals" struct in the CLI app implementation */
struct _fx_handle;
/* opaque handle, which internally holds also the sx_api_handle_t */
typedef struct _fx_handle* fx_handle_t;
 
/* Device level APIs */
 
/**
 * @brief These functions initalize/deinitialize the FX-API operations,
 *      and the underlying channel to the SDK APIs.
 *      Supported devices: Spectrum.
 *
 * @param[out] handle - handle that should be used in all
 *       further FX-API operations. Invalid handle (0) returned
 *       in case of an error.
 *
 * @return sx_status_t:
 * @return SX_STATUS_SUCCESS - Operation completes successfully
 * @return SX_STATUS_PARAM_ERROR - Input parameters error
 * @return SX_STATUS_NO_MEMORY - Memory allocation failed
 * @return SX_STATUS_ERROR - open SX-API client mutex failed
 */
sx_status_t fx_init(fx_handle_t *handle);
sx_status_t fx_deinit(fx_handle_t handle);
sx_status_t fx_extern_init(fx_handle_t handle);
sx_status_t fx_extern_deinit(fx_handle_t handle);

/**
 * @brief Flex pipe selection in fx_pipe_create/destroy() call
 */

typedef enum _fx_pipe_type_t
{
        /** ingress port flex pipe */
        FX_IN_PORT,

        /** ingress router interface flex pipe */
        FX_IN_RIF,

        /** egress rif flex pipe */
        FX_OUT_RIF,
        
        /** egress port flex pipe */
        FX_OUT_PORT

} fx_pipe_type_t;
 
/**
 * @brief This functions create/destroy a control pipeline and all it's tables.
 *      Supported devices: Spectrum.
 *
 * @param[in] handle - handle to api calls
 * @param[in] pipe_type - pipe to create/destroy
 * @param[in] if_list   - array of logical port or if numbers (uint32_t for port, uint16_t for rif)
 * @param[in] if_list_cnt - size of the if_list array
 *
 * @return sx_status_t:
 * @return SX_STATUS_SUCCESS - Operation completes successfully
 * @return SX_STATUS_PARAM_ERROR - Input parameters error
 * @return SX_STATUS_NO_MEMORY - Memory allocation failed
 */
sx_status_t fx_pipe_create(fx_handle_t handle,
        fx_pipe_type_t pipe_type,
        void *if_list,
        uint32_t if_list_cnt);

sx_status_t fx_pipe_destroy(fx_handle_t handle,
        fx_pipe_type_t pipe_type,
        void* if_list,
        uint32_t if_list_cnt);
 
 /** @brief get a list of all bindable ports
 * @param[in] handle - handle to api calls
 * @param[out] if_list   - array of logical port 
 * @param[inout] if_list_cnt - size of the if_list array
 *
 * @return sx_status_t:
 * @return SX_STATUS_SUCCESS - Operation completes successfully
 * @return SX_STATUS_PARAM_ERROR - Input parameters error
 * @return SX_STATUS_NO_MEMORY - Input list is too small
 */
sx_status_t fx_get_bindable_port_list(fx_handle_t handle, sx_port_log_id_t *if_list, uint32_t *if_list_cnt);

/** @brief get a list of all bindable rifs
 * @param[in] handle - handle to api calls
 * @param[out] if_list   - array of logical port 
 * @param[inout] if_list_cnt - size of the if_list array
 *
 * @return sx_status_t:
 * @return SX_STATUS_SUCCESS - Operation completes successfully
 * @return SX_STATUS_PARAM_ERROR - Input parameters error
 * @return SX_STATUS_NO_MEMORY - Input list is too small
 */
sx_status_t fx_get_bindable_rif_list(fx_handle_t handle, sx_router_interface_t *if_list, uint32_t *if_list_cnt);

/**
 * @brief These functions add/remove a table entry
 *      Supported devices: Spectrum.
 *
 * @param[in] handle   - handle to api calls
 * @param[in] table_id - ID (enum) of the table type
 * @param[in] keys     - byte array of keys
 * @param[in] masks    - byte array of key masks
 * @param[in] params   - byte array of parameters
 * @param[out] offset  - offset assigned in the acl table
 *
 * @return sx_status_t:
 * @return SX_STATUS_SUCCESS - Operation completes successfully
 * @return SX_STATUS_PARAM_ERROR - Input parameters error
 * @return SX_STATUS_NO_MEMORY - Memory allocation failed
 */
sx_status_t fx_table_entry_add(fx_handle_t handle, flextrum_table_id_t table_id, flextrum_action_id_t action_id, void** keys,void** masks, void** params, sx_acl_rule_offset_t* offset_ptr);
sx_status_t fx_table_entry_remove(fx_handle_t handle, flextrum_table_id_t table_id, sx_acl_rule_offset_t offset);
sx_status_t fx_table_entry_default_set(fx_handle_t handle, int table_id, int action_id, void** params);
 
/**
 * @brief This function reads a table rule counter
 *      Supported devices: Spectrum.
 *
 * @param[in] handle   - handle to api calls
 * @param[in] table_id - ID (enum) of the table type
 * @param[in] offset   - Desired rule offset
 * @param[out] bytes   - Number of bytes which hit this rule
 * @param[out] packets - Number of packets which hit this rule
 *
 * @return
 * @return sx_status_t:
 * @return SX_STATUS_SUCCESS - Operation completes successfully
 * @return SX_STATUS_FAILURE - Operation cannot be compleated
 * @return SX_STATUS_PARAM_ERROR - Invalid offset was provided
 */
sx_status_t fx_table_rule_counter_read(fx_handle_t handle, flextrum_table_id_t table_id, sx_acl_rule_offset_t offset, uint64_t *bytes, uint64_t *packets);

/**
 * @brief This function reads a table rule counter
 *      Supported devices: Spectrum.
 *
 * @param[in] handle   - handle to api calls
 * @param[in] table_id - ID (enum) of the table type
 * @param[in] offset   - Desired rule offset
 *
 * @return
 * @return sx_status_t:
 * @return SX_STATUS_SUCCESS - Operation completes successfully
 * @return SX_STATUS_FAILURE - Operation cannot be compleated
 * @return SX_STATUS_PARAM_ERROR - Invalid offset was provided
 */
sx_status_t fx_table_rule_counter_clear(fx_handle_t handle, flextrum_table_id_t table_id, sx_acl_rule_offset_t offset);

/**
 * @brief These functions prints/clear all table counters
 *      Supported devices: Spectrum.
 *
 * @param[in] handle   - handle to api calls
 * @param[in] table_id - ID (enum) of the table type
 *
 * @return
 * @return sx_status_t:
 * @return SX_STATUS_SUCCESS - Operation completes successfully
 * @return SX_STATUS_FAILURE - Operation cannot be compleated
 */
sx_status_t fx_table_rule_counters_print_all(fx_handle_t handle, flextrum_table_id_t table_id);
sx_status_t fx_table_rule_counters_clear_all(fx_handle_t handle, flextrum_table_id_t table_id);
 
 
#ifdef __cplusplus
}
#endif
 
#endif /* _FX_BASE_API_H_ */
