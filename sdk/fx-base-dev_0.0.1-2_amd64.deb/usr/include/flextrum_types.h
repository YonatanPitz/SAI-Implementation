#ifndef FLEXTRUM_TYPES_H_
#define FLEXTRUM_TYPES_H_

#ifdef __cplusplus
extern "C"{
#endif

// Spectrum 1 specific HW limit
#define PORT_NUM 32
#define RIF_NUM 400 // TODO: max output for sdk_rif_iter_get
#define DEV_ID  1
// #define ACL_SIZE 100
#define NUM_OF_TC 8
#define NUM_OF_PRIO 8
#define MAX_TABLE_NAME_LEN 200

// Maps table name to P4 runtime table ID
typedef enum{
//---------FLEX tables------
	 CONTROL_IN_PORT_TABLE_PEERING_ID = 33567947,
	 CONTROL_IN_PORT_TABLE_VHOST_ID = 33599945,
//---------FIXED tables------
} flextrum_table_id_t;

// Maps action name to P4 runtime action ID
typedef enum{
	ACTION_INVALID_ID,
	CONTROL_IN_PORT_SET_VNET_BITMAP_ID = 16779687,
	CONTROL_IN_PORT_TO_TUNNEL_ID = 16824681,
	CONTROL_IN_PORT_TO_ROUTER_ID = 16840663,
	CONTROL_IN_PORT_TO_PORT_ID = 16840951,
	NOACTION_ID = 16800567,
} flextrum_action_id_t;

//---------action structs------
// struct action_noaction_t {
// }

// struct action_control_in_port_set_vnet_bitmap_t {
// 	bit<12>*		vnet_bitmap;
// }

// struct action_control_in_port_to_tunnel_t {
// 	bit<32>*		tunnel_id;
// 	bit<32>*		underlay_dip;
// 	bit<16>*		bridge_id;
// }

// struct action_control_in_port_to_router_t {
// 	bit<32>*		router_pbs_id;
// }

// struct action_control_in_port_to_port_t {
// 	bit<32>*		port_pbs_id;
// }


#ifdef __cplusplus
}
#endif

#endif
